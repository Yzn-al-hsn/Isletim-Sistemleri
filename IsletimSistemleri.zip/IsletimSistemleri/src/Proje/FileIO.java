package Proje;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileIO {

    // Path of the file to be read or written
    private String filePath;

    // Constructor
    public FileIO(String filePath) {
        this.filePath = filePath;
    }

    // Method to read data from a file and return it as a list of strings
    public List<String> readFromFile() {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error reading file: " + filePath);
        }
        return lines;
    }
}


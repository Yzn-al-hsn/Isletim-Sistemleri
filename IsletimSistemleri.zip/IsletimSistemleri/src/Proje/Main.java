package Proje;

import java.util.*;

public class Main {
	
	private PriorityQueue<Process> realTimeQueue;
    private PriorityQueue<Process> userJobQueue;
    private ResourceManager resourceManager;
    private boolean dispatcherIsRunning;
    private int currentTime;
	
	public Main()
	{
		// Priority Queue with comparator based on arrival time and priority
        realTimeQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getArrivalTime));
        userJobQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getPriority));
        resourceManager = new ResourceManager();
        dispatcherIsRunning = true;
        currentTime = 0;
	}
	
	

    public static void main(String[] args) {
        // Path to the file containing process data
        String filePath = "./src/giris.txt"; // Update this with the actual file path
        printHeader();
        // Create and initialize the simulation controller
        SimulationController controller = new SimulationController(filePath);
        controller.initialize();

        
        
        // Start the simulation
        controller.start();

        
        // Additional logic can be added here, if needed

        // Stop the simulation (can be triggered by an event or condition in a more complex implementation)
        controller.stop();
    }
    
    private static void printHeader() {
        System.out.println("Pid\tarrival\tpriority\tcpu\tMBytes\tprn\tscn\tmodem\tcd\tstatus");
        System.out.println("======================================================================");
    }
    
    public void startDispatcher() {
        while (dispatcherIsRunning) {
            Process process = getNextProcess();
            if (process != null) {
                if (process.isRealTime() && process.getArrivalTime() <= currentTime) {
                    executeRealTimeProcess(process);
                } else if (process.getArrivalTime() <= currentTime) {
                    executeUserJob(process);
                }
            }

            if (realTimeQueue.isEmpty() && userJobQueue.isEmpty()) {
                dispatcherIsRunning = false; // No more processes to run
            }

            currentTime++; // Simulate the passage of time
            try {
                Thread.sleep(1000); // Sleep for one second (simulated dispatcher tick)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
	
	private Process getNextProcess() {
        // Real-time jobs take precedence over user jobs
        if (!realTimeQueue.isEmpty()) {
            return realTimeQueue.peek(); // Peek at the next real-time job
        } else if (!userJobQueue.isEmpty()) {
            return userJobQueue.peek(); // Peek at the next user job
        }
        return null;
    }

    private void executeRealTimeProcess(Process process) {
        // Simulate the execution of a real-time process
        System.out.println("Executing Real-Time Process: " + process);
        process.runProcess(); // You would define this method in Process class

        // Once a real-time process starts, it runs to completion
        realTimeQueue.poll(); // Remove from the queue
        process.setState(Process.State.COMPLETED);
        releaseResources(process);
    }

    private void executeUserJob(Process process) {
        // Simulate the execution of a user job
        System.out.println("Executing User Job: " + process);
        process.runProcess(); // Simulate process execution

        // User jobs run for one tick then are re-evaluated
        userJobQueue.poll(); // Remove from the queue
        if (process.getCpuTime() > 0) {
            // Lower the priority and add back to the queue if it still needs more CPU time
            process.lowerPriority();
            userJobQueue.offer(process);
        } else {
            // If the job is complete, it's terminated
            process.setState(Process.State.COMPLETED);
            releaseResources(process);
        }
    }

    private void releaseResources(Process process) {
        // Release the resources allocated to a process
        System.out.println("Releasing resources for Process: " + process);
        resourceManager.releaseResources(process);
    }
}

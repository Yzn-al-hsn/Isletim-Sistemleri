package Proje;

import java.util.*;

public class FCFSScheduler {
    private Queue<Process> highPriorityQueue;

    public FCFSScheduler() {
        // Priority Queue with comparator based only on arrival time
        highPriorityQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getArrivalTime));
    }

    public void schedule(Process process) {
        highPriorityQueue.add(process);
    }

    public Process dispatch() {
        return highPriorityQueue.poll(); // Dispatch based on arrival time
    }
}

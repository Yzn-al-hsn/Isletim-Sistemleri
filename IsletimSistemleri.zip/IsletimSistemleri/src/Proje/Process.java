package Proje;

public class Process {
	// Enum for process states for better readability and error prevention
    public enum State {
        NEW, READY, RUNNING, WAITING, COMPLETED
    }

    private int pid;
    private int arrivalTime;
    private int priority;
    private int cpuTime;
    private int memory; // MBytes
    private boolean printer; // prn
    private boolean scanner; // scn
    private boolean modem;
    private boolean cd;
    private State state;
    private boolean isRealTime;

    // Updated constructor
    public Process(int pid, int arrivalTime, int priority, int cpuTime, int memory,
                   boolean printer, boolean scanner, boolean modem, boolean cd) {
        this.pid = pid;
        this.arrivalTime = arrivalTime;
        this.priority = priority;
        this.cpuTime = cpuTime;
        this.memory = memory;
        this.printer = printer;
        this.scanner = scanner;
        this.modem = modem;
        this.cd = cd;
        this.state = State.NEW;
    }

    public int getPid() {
        return pid;
    }
    
    public void setPid(int pid) {
        this.pid=pid;
    }

    public int getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(int arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
    
    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getCpuTime() {
        return cpuTime;
    }

    public void setCpuTime(int cpuTime) {
        this.cpuTime = cpuTime;
    }
    
    public int getMemory() {
        return memory;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }
    
    public boolean getPrinter() {
        return printer;
    }

    public void setPrinter(boolean printer) {
        this.printer = printer;
    }
    
    public boolean getScanner() {
        return scanner;
    }

    public void setScanner(boolean scanner) {
        this.scanner = scanner;
    }
    
    public boolean getModem() {
        return modem;
    }

    public void setModem(boolean modem) {
        this.modem = modem;
    }
    
    public boolean getCd() {
        return cd;
    }

    public void setCd(boolean cd) {
        this.cd = cd;
    }
    
    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

 

    
    
    public boolean isRealTime() {
        return isRealTime;
    }

    // Simulate the execution of the process
    public void runProcess() {
        
        // Reduce CPU time as it's a simulation of process execution
        cpuTime--;
    }

    public void lowerPriority() {
        // Lower the priority for the next round
        priority++;
    }

    // String representation for debugging and logging
    @Override
    public String toString() {
        return  ""+ pid+"\t" + arrivalTime+"\t" + priority+"\t" + cpuTime+"\t" + memory+"\t" + printer+"\t" + scanner+"\t" + priority+"\t" +modem+"\t" + cd+"\t"+state ;
    }
}

package Proje;

public class SimulationController {

    private ProcessQueue processQueue;
    private Dispatcher dispatcher;
    private ResourceManager resourceManager;
    private FileIO fileIO;
    private boolean isRunning;
    private int pidCounter=0;

    // Constructor
    public SimulationController(String filePath) {
        this.processQueue = new ProcessQueue();
        this.dispatcher = new Dispatcher(processQueue);
        this.resourceManager = new ResourceManager();
        this.fileIO = new FileIO(filePath);
        this.isRunning = false;
    }

    // Method to initialize the simulation from a file
    public void initialize() {

        for (String line : fileIO.readFromFile()) {
            String[] parts = line.split(",");
            int pid = pidCounter++;
            int arrivalTime = Integer.parseInt(parts[0].trim());
            int priority = Integer.parseInt(parts[1].trim());
            int cpuTime = Integer.parseInt(parts[2].trim());
            int memory = Integer.parseInt(parts[3].trim());
            boolean printer = Integer.parseInt(parts[4].trim())!=0 ? true: false;
            boolean scanner = Integer.parseInt(parts[5].trim())!=0 ? true: false;
            boolean modem = Integer.parseInt(parts[6].trim())!=0 ? true: false;
            boolean cd = Integer.parseInt(parts[7].trim())!=0 ? true: false;

            Process process = new Process(pid, arrivalTime, priority, cpuTime, memory,
                                          printer, scanner, modem, cd);
            processQueue.enqueue(process);
            
        }

    }

    // Method to start the simulation
    public void start() {
        isRunning = true;

        while (isRunning && !processQueue.isEmpty()) {
            // Dispatch the next process
            dispatcher.dispatchNextProcess();

            // Resource management and other logic can be added here
        }

    }

    // Method to stop the simulation
    public void stop() {
        System.out.println("Stopping simulation...");
        isRunning = false;
    }
}

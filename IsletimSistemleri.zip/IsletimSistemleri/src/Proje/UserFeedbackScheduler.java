package Proje;

import java.util.*;

public class UserFeedbackScheduler {
    private List<Queue<Process>> feedbackQueues;
    private final int maxPriority;

    public UserFeedbackScheduler(int maxPriority) {
        this.maxPriority = maxPriority;
        feedbackQueues = new ArrayList<>(maxPriority);
        for (int i = 0; i < maxPriority; i++) {
            feedbackQueues.add(new LinkedList<>());
        }
    }

    public void schedule(Process process) {
        int priority = process.getPriority();
        if (priority < maxPriority) {
            feedbackQueues.get(priority).add(process);
        } else {
            // Handle invalid priority or place in the lowest priority queue
        }
    }

    public Process dispatch() {
        // Iterate over queues from highest to lowest priority
        for (Queue<Process> queue : feedbackQueues) {
            if (!queue.isEmpty()) {
                return queue.poll(); // Dispatch the first process from the highest priority queue
            }
        }
        return null;
    }

    public void feedback(Process process) {
        // Lower the process's priority and reschedule it
        int priority = process.getPriority();
        if (priority + 1 < maxPriority) {
            process.setPriority(priority + 1);
        }
        schedule(process);
    }
}


package Proje;

import java.util.PriorityQueue;
import java.util.Comparator;

public class ProcessQueue {

    // Custom comparator for sorting processes by priority
    private static class ProcessComparator implements Comparator<Process> {
        @Override
        public int compare(Process p1, Process p2) {
            return Integer.compare(p1.getPriority(), p2.getPriority());
        }
    }

    // PriorityQueue to hold processes
    private PriorityQueue<Process> queue;

    // Constructor
    public ProcessQueue() {
        // Initialize the PriorityQueue with the custom comparator
        this.queue = new PriorityQueue<>(new ProcessComparator());
    }

    // Method to add a process to the queue
    public void enqueue(Process process) {
        queue.add(process);
    }

    // Method to remove and return the highest priority process
    public Process dequeue() {
        return queue.poll();
    }

    // Method to peek at the highest priority process without removing it
    public Process peek() {
        return queue.peek();
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // Method to get the size of the queue
    public int size() {
        return queue.size();
    }

    // Method for debugging and logging
    public void printQueue() {
        System.out.println("Current Process Queue:");
        for (Process process : queue) {
            System.out.println(process);
        }
    }
}


package Proje;

import java.util.HashMap;
import java.util.Map;

public class ResourceManager {

	
	// Resource availability
    private int availablePrinters = 2;
    private int availableScanners = 1;
    private int availableModems = 1;
    private int availableCDDrives = 2;
    private int availableMemory = 1024; // in MBytes
    
    
    // Map to track resource allocation to processes
    // The key is the resource ID, and the value is the PID of the process currently holding the resource
    private Map<Integer, Integer> resourceAllocation;

    // Constructor
    public ResourceManager() {
       
    }
    
    public int getAvailablePrinters()
    {
    	return availablePrinters;
    }
    
    public int getAvailableScanners()
    {
    	return availableScanners;
    }
    
    public int getAvailableModems()
    {
    	return availableModems;
    }
    
    public int getAvailableCDDrives()
    {
    	return availableCDDrives;
    }
    
    public int getAvailableMemory()
    {
    	return availableMemory;
    }
    
    public void releaseResources(Process process) {
        // Logic to release resources held by the process
        System.out.println("Resources released for Process: " + process.getPid());
    }

    // Method to allocate a resource to a process
    public boolean allocateResources(Process process) {
        // Check if all required resources are available
        if (process.getMemory() <= availableMemory &&
            (!process.getPrinter() || availablePrinters > 0) &&
            (!process.getScanner() || availableScanners > 0) &&
            (!process.getModem() || availableModems > 0) &&
            (!process.getCd() || availableCDDrives > 0)) {

            // Allocate resources
            availableMemory -= process.getMemory();
            if (process.getPrinter()) availablePrinters--;
            if (process.getScanner()) availableScanners--;
            if (process.getModem()) availableModems--;
            if (process.getCd()) availableCDDrives--;

            return true;
        } else {
            return false; // Resources are not available
        }
    }

 // Method to deallocate resources from a process
    public void deallocateResources(Process process) {
        availableMemory += process.getMemory();
        if (process.getPrinter()) availablePrinters++;
        if (process.getScanner()) availableScanners++;
        if (process.getModem()) availableModems++;
        if (process.getCd()) availableCDDrives++;
    }
    // Method to deallocate a resource from a process
    public void deallocateResource(int resourceId) {
        resourceAllocation.put(resourceId, null);
        System.out.println("Resource " + resourceId + " deallocated");
    }
}


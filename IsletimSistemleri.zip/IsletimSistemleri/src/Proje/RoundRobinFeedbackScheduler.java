package Proje;

import java.util.*;

public class RoundRobinFeedbackScheduler {

	private List<Queue<Process>> feedbackQueues;
    private final int maxPriority;
    private final int timeSlice; // Quantum time for Round Robin

    public RoundRobinFeedbackScheduler(int maxPriority, int timeSlice) {
        this.maxPriority = maxPriority;
        this.timeSlice = timeSlice;
        feedbackQueues = new ArrayList<>(maxPriority);

        // Initialize queues for each priority level
        for (int i = 0; i < maxPriority; i++) {
            feedbackQueues.add(new LinkedList<>());
        }
    }

    public void schedule(Process process) {
        int priority = process.getPriority();
        if (priority < maxPriority) {
            feedbackQueues.get(priority).add(process);
        } else {
            // Handle invalid priority or place in the lowest priority queue
            feedbackQueues.get(maxPriority - 1).add(process);
        }
    }

    public void dispatch() {
        for (int i = 0; i < feedbackQueues.size(); i++) {
            Queue<Process> queue = feedbackQueues.get(i);

            if (!queue.isEmpty()) {
                Process process = queue.poll(); // Get the next process from the queue

                // Simulate process execution for a time slice
                int remainingCpuTime = process.getCpuTime() - timeSlice;
                if (remainingCpuTime > 0) {
                    process.setCpuTime(remainingCpuTime);
                    // Lower the priority and place the process at the end of its new queue
                    feedback(process);
                } else {
                    process.setCpuTime(0);
                    process.setState(Process.State.COMPLETED);
                    // No need to re-queue the process as it is finished
                }

                // In a real system, we would now start the process's execution
                // Since this is a simulation, we simply print the process info
                System.out.println("Process ID: " + process.getPid() + " Priority: " + process.getPriority() +
                        " Remaining CPU Time: " + process.getCpuTime() + " State: " + process.getState());
                break; // Break after dispatching one process for this tick
            }
        }
    }

    private void feedback(Process process) {
        int currentPriority = process.getPriority();
        if (currentPriority + 1 < maxPriority) {
            process.setPriority(currentPriority + 1);
        }
        feedbackQueues.get(process.getPriority()).add(process);
    }
    
    // Getter for feedbackQueues (useful for tests and external checks)
    public List<Queue<Process>> getFeedbackQueues() {
        return feedbackQueues;
    }
}

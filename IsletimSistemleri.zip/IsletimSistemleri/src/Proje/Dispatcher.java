package Proje;

public class Dispatcher {

    // The process queue from which the dispatcher will get processes
    private ProcessQueue processQueue;
    private ResourceManager resourceManager;
    // The currently running process
    private Process currentProcess;

    // Constructor
    public Dispatcher(ProcessQueue processQueue) {
        this.processQueue = processQueue;
        this.currentProcess = null;
        this.resourceManager = new ResourceManager();
    }

    // Dispatch the next process from the queue
    public void dispatchNextProcess() {
        if (!processQueue.isEmpty()) {
            currentProcess = processQueue.dequeue();
            currentProcess.setState(Process.State.RUNNING);

            // Simulate process execution
            currentProcess.runProcess();
            resourceManager.allocateResources(currentProcess);
            // After execution, update process state
            currentProcess.setState(Process.State.COMPLETED);
            
            printProcess(currentProcess);
            
            resourceManager.deallocateResources(currentProcess);
        } 
    }
    
    private void printProcess(Process process) {
    	if(process.getCpuTime()>20)
    	{
    		System.out.println(process.getPid()+"\tHATA - proses zaman aşımı (20 sn de tamamlanamadı)");
    	}
    	else if(process.getPriority()==0 &&process.getMemory()>64)
    	{
    		System.out.println(process.getPid()+"\tHATA - Gerçek zamanlı proses (64MB)  tan daha fazla bellek talep ediyor - proses silindi");
    	}
    	else if(process.getMemory()>960)
    	{
    		System.out.println(process.getPid()+"\tHATA - proses (960MB)  tan daha fazla bellek talep ediyor - proses silindi");
    	}
    	else if(resourceManager.getAvailablePrinters()<=0 || resourceManager.getAvailableScanners()<=0 || resourceManager.getAvailableModems()<=0 || resourceManager.getAvailableCDDrives()<=0 || resourceManager.getAvailableMemory()<=0 )
    	{
    		System.out.println(process.getPid()+"\tHATA - proses çok sayıda kaynak talep ediliyor - proses silindi");
    	}
    	else
    	{
    		System.out.printf("%d   \t%s\t   %d\t\t%d\t%d\t%d\t%d\t%d\t%d\t%s\n",
                    process.getPid(),
                    process.getArrivalTime(),
                    process.getPriority(),
                    process.getCpuTime(),
                    process.getMemory(),
                    process.getPrinter() ? 1 : 0,
                    process.getScanner() ? 1 : 0,
                    process.getModem() ? 1 : 0,
                    process.getCd() ? 1 : 0,
                    process.getState()
            );
    	}
    }

    // Method to get the currently running process
    public Process getCurrentProcess() {
        return currentProcess;
    }

    // Method to preempt the current process (if needed)
    public void preemptCurrentProcess() {
        if (currentProcess != null) {
            System.out.println("Preempting process: " + currentProcess.getPid());
            currentProcess.setState(Process.State.READY);
            processQueue.enqueue(currentProcess);
            currentProcess = null;
        }
    }
}


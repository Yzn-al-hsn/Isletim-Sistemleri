package Proje;

import java.util.PriorityQueue;
import java.util.Comparator;

public class ProcessQueue {

    // İşlemleri önceliğe göre sıralamak için özel karşılaştırıcı
    private static class ProcessComparator implements Comparator<Process> {
        @Override
        public int compare(Process p1, Process p2) {
            return Integer.compare(p1.getPriority(), p2.getPriority());
        }
    }

    // İşlemleri tutmak için PriorityQueue
    private PriorityQueue<Process> queue;

    // Yapıcı
    public ProcessQueue() {
        // PriorityQueue'yu özel karşılaştırıcıyla başlatın
        this.queue = new PriorityQueue<>(new ProcessComparator());
    }

    // Kuyruğa bir işlem ekleme yöntemi
    public void enqueue(Process process) {
        queue.add(process);
    }

    // En yüksek öncelikli işlemi kaldırma ve geri döndürme yöntemi
    public Process dequeue() {
        return queue.poll();
    }

    // En yüksek öncelikli sürece onu kaldırmadan göz atma yöntemi
    public Process peek() {
        return queue.peek();
    }

    // Kuyruğun boş olup olmadığını kontrol etme yöntemi
    public boolean isEmpty() {
        return queue.isEmpty();
    }

    // Kuyruğun boyutunu alma yöntemi
    public int size() {
        return queue.size();
    }
}


package Proje;

import java.util.*;

public class FCFSScheduler {
    private Queue<Process> highPriorityQueue;

    public FCFSScheduler() {
        // Yalnızca varış saatine dayalı karşılaştırıcılı Öncelik Kuyruğu
        highPriorityQueue = new PriorityQueue<>(Comparator.comparingInt(Process::getArrivalTime));
    }

    public void schedule(Process process) {
        highPriorityQueue.add(process);
    }

    public Process dispatch() {
        return highPriorityQueue.poll(); // Varış saatine göre gönderim
    }
}

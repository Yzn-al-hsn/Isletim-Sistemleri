package Proje;

import java.util.*;

public class UserFeedbackScheduler {
    private List<Queue<Process>> feedbackQueues;
    private final int maxPriority;

    public UserFeedbackScheduler(int maxPriority) {
        this.maxPriority = maxPriority;
        feedbackQueues = new ArrayList<>(maxPriority);
        for (int i = 0; i < maxPriority; i++) {
            feedbackQueues.add(new LinkedList<>());
        }
    }

    public void schedule(Process process) {
        int priority = process.getPriority();
        if (priority < maxPriority) {
            feedbackQueues.get(priority).add(process);
        } else {
            //Geçersiz önceliği ele alın veya en düşük öncelik sırasına yerleştirin
        }
    }

    public Process dispatch() {
        // Kuyruklar üzerinde en yüksek öncelikten en düşük önceliğe doğru yineleme
        for (Queue<Process> queue : feedbackQueues) {
            if (!queue.isEmpty()) {
                return queue.poll(); // İlk işlemi en yüksek öncelikli kuyruktan gönder
            }
        }
        return null;
    }

    public void feedback(Process process) {
        // Sürecin önceliğini düşürün ve yeniden planlayın
        int priority = process.getPriority();
        if (priority + 1 < maxPriority) {
            process.setPriority(priority + 1);
        }
        schedule(process);
    }
}


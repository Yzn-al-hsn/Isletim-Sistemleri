package Proje;

public class Main {

    public static void main(String[] args) {
        // İşlem verilerini içeren dosyanın yolu
        String filePath = "./src/giris.txt";
        printHeader();
        // Simülasyon denetleyicisini oluşturun ve başlatın
        SimulationController controller = new SimulationController(filePath);
        controller.initialize();

        // Simülasyonu başlat
        controller.start();


        // Simülasyonu durdur
        controller.stop();
    }
    
    private static void printHeader() {
        System.out.println("Pid\tarrival\tpriority\tcpu\tMBytes\tprn\tscn\tmodem\tcd\tstatus");
        System.out.println("======================================================================");
    }
    
    
}

package Proje;

import java.util.*;

public class RoundRobinFeedbackScheduler {

	private List<Queue<Process>> feedbackQueues;
    private final int maxPriority;
    private final int timeSlice; // Round Robin için kuantum zamanı

    public RoundRobinFeedbackScheduler(int maxPriority, int timeSlice) {
        this.maxPriority = maxPriority;
        this.timeSlice = timeSlice;
        feedbackQueues = new ArrayList<>(maxPriority);

        // Her öncelik düzeyi için kuyrukları başlatın
        for (int i = 0; i < maxPriority; i++) {
            feedbackQueues.add(new LinkedList<>());
        }
    }

    public void schedule(Process process) {
        int priority = process.getPriority();
        if (priority < maxPriority) {
            feedbackQueues.get(priority).add(process);
        } else {
            // Geçersiz önceliği ele alın veya en düşük öncelik sırasına yerleştirin
            feedbackQueues.get(maxPriority - 1).add(process);
        }
    }

    public void dispatch() {
        for (int i = 0; i < feedbackQueues.size(); i++) {
            Queue<Process> queue = feedbackQueues.get(i);

            if (!queue.isEmpty()) {
                Process process = queue.poll(); // Kuyruktan bir sonraki işlemi alın

                // Bir zaman dilimi için süreç yürütmeyi simüle edin
                int remainingCpuTime = process.getCpuTime() - timeSlice;
                if (remainingCpuTime > 0) {
                    process.setCpuTime(remainingCpuTime);
                    // Önceliği düşürün ve işlemi yeni kuyruğunun sonuna yerleştirin
                    feedback(process);
                } else {
                    process.setCpuTime(0);
                    process.setState(Process.State.COMPLETED);
                    //İşlem bittiğinde yeniden kuyruğa almanıza gerek yok
                }

                // Gerçek bir sistemde artık sürecin yürütülmesine başlayacağız
                // Bu bir simülasyon olduğu için sadece süreç bilgisini yazdırıyoruz
                System.out.println("Process ID: " + process.getPid() + " Priority: " + process.getPriority() +
                        " Remaining CPU Time: " + process.getCpuTime() + " State: " + process.getState());
                break; // Bu onay işareti için bir işlemi gönderdikten sonra ara verin
            }
        }
    }

    private void feedback(Process process) {
        int currentPriority = process.getPriority();
        if (currentPriority + 1 < maxPriority) {
            process.setPriority(currentPriority + 1);
        }
        feedbackQueues.get(process.getPriority()).add(process);
    }
  
}

package Proje;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileIO {

    // Okunacak veya yazılacak dosyanın yolu
    private String filePath;

    // Yapıcı
    public FileIO(String filePath) {
        this.filePath = filePath;
    }

    // Bir dosyadan veri okuma ve onu bir dize listesi olarak döndürme yöntemi
    public List<String> readFromFile() {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error reading file: " + filePath);
        }
        return lines;
    }
}


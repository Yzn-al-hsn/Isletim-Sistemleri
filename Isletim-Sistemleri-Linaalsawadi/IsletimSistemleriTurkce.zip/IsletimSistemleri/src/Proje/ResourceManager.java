package Proje;

import java.util.HashMap;
import java.util.Map;

public class ResourceManager {

	
	// Kaynak kullanılabilirliği
    private int availablePrinters = 2;
    private int availableScanners = 1;
    private int availableModems = 1;
    private int availableCDDrives = 2;
    private int availableMemory = 1024; // MBytes
    
    
    // Süreçlere kaynak tahsisini izlemek için harita
    // Anahtar, kaynak kimliğidir ve değer, şu anda kaynağı tutan işlemin PID'sidir.
    private Map<Integer, Integer> resourceAllocation;

    // Yapıcı
    public ResourceManager() {
       
    }
    
    public int getAvailablePrinters()
    {
    	return availablePrinters;
    }
    
    public int getAvailableScanners()
    {
    	return availableScanners;
    }
    
    public int getAvailableModems()
    {
    	return availableModems;
    }
    
    public int getAvailableCDDrives()
    {
    	return availableCDDrives;
    }
    
    public int getAvailableMemory()
    {
    	return availableMemory;
    }

    // Bir sürece kaynak tahsis etme yöntemi
    public boolean allocateResources(Process process) {
        // Gerekli tüm kaynakların mevcut olup olmadığını kontrol edin
        if (process.getMemory() <= availableMemory &&
            (!process.getPrinter() || availablePrinters > 0) &&
            (!process.getScanner() || availableScanners > 0) &&
            (!process.getModem() || availableModems > 0) &&
            (!process.getCd() || availableCDDrives > 0)) {

            // Kaynakları tahsis edin
            availableMemory -= process.getMemory();
            if (process.getPrinter()) availablePrinters--;
            if (process.getScanner()) availableScanners--;
            if (process.getModem()) availableModems--;
            if (process.getCd()) availableCDDrives--;

            return true;
        } else {
            return false; // Kaynaklar mevcut değil
        }
    }

 // Method to deallocate resources from a process
    public void deallocateResources(Process process) {
        availableMemory += process.getMemory();
        if (process.getPrinter()) availablePrinters++;
        if (process.getScanner()) availableScanners++;
        if (process.getModem()) availableModems++;
        if (process.getCd()) availableCDDrives++;
    }
    
}

